import type { Position } from './Position.ts'

/**
 * スライド後の変化点だけを Scene と UI に渡すための型で、盤面全体を毎回比較しなくて済むようにするために必要である。
 */
export interface MoveResult {
    moved: boolean
    tileId: number
    from: Position | null
    to: Position | null
    carriedTurtle: boolean
}
