declare namespace Phaser {
    const AUTO: number

    namespace Scale {
        const FIT: number
        const CENTER_BOTH: number
    }

    interface GameConfig {
        type: number
        title?: string
        description?: string
        parent?: string
        width: number
        height: number
        backgroundColor?: string
        pixelArt?: boolean
        scene: SceneConstructor[]
        scale?: {
            mode: number
            autoCenter: number
        }
    }

    interface SceneConstructor {
        new (): Scene
    }

    class Game {
        constructor(config: GameConfig)
    }

    class Scene {
        constructor(key: string)
        add: AddFactory
        cameras: {
            main: Camera
        }
        time: TimeManager
        tweens: TweenManager
        scene: SceneManager
    }

    interface Camera {
        setBackgroundColor(color: string): void
    }

    interface AddFactory {
        container(x: number, y: number): GameObjects.Container
        rectangle(x: number, y: number, width: number, height: number, color?: number, alpha?: number): GameObjects.Rectangle
        circle(x: number, y: number, radius: number, color?: number, alpha?: number): GameObjects.Circle
        text(x: number, y: number, text: string, style?: TextStyle): GameObjects.Text
    }

    interface TextStyle {
        fontFamily?: string
        fontSize?: string
        color?: string
        align?: string
        backgroundColor?: string
        padding?: {
            left?: number
            right?: number
            top?: number
            bottom?: number
        }
    }

    interface TimeManager {
        addEvent(config: TimeEventConfig): TimeEvent
    }

    interface TimeEventConfig {
        delay: number
        loop?: boolean
        callback: () => void
    }

    interface TimeEvent {
        remove(): void
    }

    interface TweenManager {
        add(config: TweenConfig): void
    }

    interface TweenConfig {
        targets: GameObjects.Container
        x?: number
        y?: number
        duration: number
        ease?: string
        onComplete?: () => void
    }

    interface SceneManager {
        start(key: string): void
        restart(): void
    }

    namespace GameObjects {
        class Container {
            x: number
            y: number
            add(child: Rectangle | Circle | Text | Container): this
            setSize(width: number, height: number): this
            setInteractive(hitArea?: unknown, callback?: (...args: unknown[]) => boolean): this
            on(eventName: string, handler: () => void): this
            setVisible(visible: boolean): this
            destroy(): void
        }

        class Rectangle {
            x: number
            y: number
            setOrigin(x: number, y?: number): this
            setStrokeStyle(lineWidth: number, color: number, alpha?: number): this
            setFillStyle(color: number, alpha?: number): this
            destroy(): void
        }

        class Circle {
            x: number
            y: number
            setStrokeStyle(lineWidth: number, color: number, alpha?: number): this
            destroy(): void
        }

        class Text {
            setOrigin(x: number, y?: number): this
            setText(text: string): this
            setColor(color: string): this
            setInteractive(): this
            on(eventName: string, handler: () => void): this
            destroy(): void
        }
    }
}

declare const Phaser: {
    AUTO: number
    Scale: {
        FIT: number
        CENTER_BOTH: number
    }
    Scene: Phaser.SceneConstructor
    Game: new (config: Phaser.GameConfig) => Phaser.Game
    Geom: {
        Rectangle: {
            new (x: number, y: number, width: number, height: number): unknown
            Contains: (...args: unknown[]) => boolean
        }
    }
}
