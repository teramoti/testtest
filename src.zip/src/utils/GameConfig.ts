/**
 * ゲーム全体の調整値を一箇所に集めるための定義で、Scene や Manager 間で速度や得点条件がずれないようにするために必要である。
 */
export class GameConfig {
    static readonly GAME_WIDTH = 1280
    static readonly GAME_HEIGHT = 720
    static readonly SESSION_SECONDS = 80
    static readonly BOARD_SIZE = 4
    static readonly TILE_SIZE = 118
    static readonly BOARD_ORIGIN_X = 404
    static readonly BOARD_ORIGIN_Y = 154
    static readonly TURTLE_STEP_MS = 790
    static readonly TURTLE_STEP_ACCELERATION_MS = 70
    static readonly MIN_TURTLE_STEP_MS = 320
    static readonly BOOST_TURTLE_STEP_REDUCTION_MS = 240
    static readonly MIN_BOOST_TURTLE_STEP_MS = 170
    static readonly START_ROUTE_LENGTH = 8
    static readonly MAX_LAYOUT_ATTEMPTS = 900
    static readonly INITIAL_JEWEL_COUNT = 6
    static readonly PRIORITY_ROUTE_JEWEL_COUNT = 3
    static readonly JEWEL_SCORE = 50
    static readonly COMBO_WINDOW_MS = 7000
    static readonly MAX_FLOW_COUNT = 8
    static readonly FLOW_BIG_PLAY_COUNT = 4
    static readonly SPEED_SCORE_STEP = 900
    static readonly ROUTE_PREVIEW_LIMIT = 20
    static readonly WARNING_ROUTE_STEPS = 3
    static readonly DANGER_ROUTE_STEPS = 1
    static readonly TIME_WARNING_SECONDS = 18
    static readonly TIME_DANGER_SECONDS = 8
    static readonly RETRY_DELAY_MS = 1500
    static readonly SLIDE_TWEEN_MS = 190
    static readonly TURTLE_TWEEN_MS = 250
    static readonly BATTLE_RIVAL_OPENING_POINTS = 48
    static readonly BATTLE_RIVAL_MIDDLE_POINTS = 68
    static readonly BATTLE_RIVAL_FINALE_POINTS = 94
    static readonly BATTLE_RIVAL_CRASH_SWING = 260
    static readonly BATTLE_RIVAL_SURGE_SECONDS = 4
    static readonly BATTLE_PLAYER_SURGE_SECONDS = 3
}
