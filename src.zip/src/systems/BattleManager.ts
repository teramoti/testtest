import type { BattlePhase, BattleSnapshot, BattleState } from '../models/BattleSnapshot.ts'
import type { ScoreSnapshot } from '../models/ScoreSnapshot.ts'
import { GameConfig } from '../utils/GameConfig.ts'

export class BattleManager {
    private playerScore: number
    private rivalScore: number
    private playerSurgeSeconds: number
    private rivalSurgeSeconds: number
    private message: string

    constructor() {
        this.playerScore = 0
        this.rivalScore = 0
        this.playerSurgeSeconds = 0
        this.rivalSurgeSeconds = 0
        this.message = 'NEUTRAL'
    }

    reset(): BattleSnapshot {
        this.playerScore = 0
        this.rivalScore = 0
        this.playerSurgeSeconds = 0
        this.rivalSurgeSeconds = 0
        this.message = 'OPENING'
        return this.getSnapshot(GameConfig.SESSION_SECONDS)
    }

    syncPlayerScore(scoreSnapshot: ScoreSnapshot, timeLeft: number): BattleSnapshot {
        this.playerScore = scoreSnapshot.score
        return this.getSnapshot(timeLeft)
    }

    advanceClock(timeLeft: number, scoreSnapshot: ScoreSnapshot): BattleSnapshot {
        this.playerScore = scoreSnapshot.score
        const phase = this.getPhase(timeLeft)
        let rivalGain = this.getBaseRivalGain(phase)
        rivalGain += this.getCatchUpAdjustment(scoreSnapshot.score)
        rivalGain += this.getTempoAdjustment(scoreSnapshot)
        rivalGain += this.getOscillation(timeLeft)

        if (this.playerSurgeSeconds > 0) {
            rivalGain -= 8
            this.playerSurgeSeconds -= 1
            this.message = 'PLAYER SURGE'
        } else if (this.rivalSurgeSeconds > 0) {
            rivalGain += 12
            this.rivalSurgeSeconds -= 1
            this.message = 'RIVAL SURGE'
        } else {
            this.message = this.getDefaultMessage(scoreSnapshot.score, timeLeft)
        }

        this.rivalScore += Math.max(10, rivalGain)
        return this.getSnapshot(timeLeft)
    }

    registerCrash(timeLeft: number): BattleSnapshot {
        this.rivalScore += GameConfig.BATTLE_RIVAL_CRASH_SWING
        this.rivalSurgeSeconds = Math.max(this.rivalSurgeSeconds, GameConfig.BATTLE_RIVAL_SURGE_SECONDS)
        this.message = 'RIVAL BREAK'
        return this.getSnapshot(timeLeft)
    }

    registerBigPlay(timeLeft: number, kind: 'combo' | 'rescue' | 'loop'): BattleSnapshot {
        if (kind === 'combo') {
            this.playerSurgeSeconds = Math.max(this.playerSurgeSeconds, 2)
            this.message = 'FLOW PUSH'
        } else if (kind === 'rescue') {
            this.playerSurgeSeconds = Math.max(this.playerSurgeSeconds, GameConfig.BATTLE_PLAYER_SURGE_SECONDS)
            this.message = 'SAVE BONUS'
        } else {
            this.playerSurgeSeconds = Math.max(this.playerSurgeSeconds, GameConfig.BATTLE_PLAYER_SURGE_SECONDS + 1)
            this.message = 'LOOP BONUS'
        }

        return this.getSnapshot(timeLeft)
    }

    getSnapshot(timeLeft: number): BattleSnapshot {
        const total = Math.max(1, this.playerScore + this.rivalScore)
        const scoreDiff = this.playerScore - this.rivalScore
        const phase = this.getPhase(timeLeft)

        return {
            playerScore: this.playerScore,
            rivalScore: this.rivalScore,
            scoreDiff,
            state: this.getState(scoreDiff),
            phase,
            phaseLabel: this.getPhaseLabel(phase),
            message: this.message,
            playerGaugeRatio: this.playerScore / total,
            rivalGaugeRatio: this.rivalScore / total,
            momentum: this.playerSurgeSeconds - this.rivalSurgeSeconds,
            result: scoreDiff > 0 ? 'win' : scoreDiff < 0 ? 'lose' : 'draw',
        }
    }

    private getPhase(timeLeft: number): BattlePhase {
        const progress = 1 - timeLeft / GameConfig.SESSION_SECONDS

        if (progress >= 0.72) {
            return 'finale'
        }

        if (progress >= 0.34) {
            return 'middle'
        }

        return 'opening'
    }

    private getPhaseLabel(phase: BattlePhase): string {
        if (phase === 'opening') {
            return 'OPENING HEAT'
        }

        if (phase === 'middle') {
            return 'MID TIDE'
        }

        return 'FINAL RUSH'
    }

    private getBaseRivalGain(phase: BattlePhase): number {
        if (phase === 'opening') {
            return GameConfig.BATTLE_RIVAL_OPENING_POINTS
        }

        if (phase === 'middle') {
            return GameConfig.BATTLE_RIVAL_MIDDLE_POINTS
        }

        return GameConfig.BATTLE_RIVAL_FINALE_POINTS
    }

    private getCatchUpAdjustment(playerScore: number): number {
        const diff = playerScore - this.rivalScore

        if (diff >= 1500) {
            return 28
        }

        if (diff >= 900) {
            return 20
        }

        if (diff >= 450) {
            return 12
        }

        if (diff <= -1500) {
            return -18
        }

        if (diff <= -900) {
            return -12
        }

        if (diff <= -450) {
            return -6
        }

        return 0
    }

    private getTempoAdjustment(scoreSnapshot: ScoreSnapshot): number {
        let adjustment = 0

        if (scoreSnapshot.comboActive) {
            adjustment -= Math.min(12, scoreSnapshot.comboCount * 2)
        }

        if (scoreSnapshot.crashCount > 0 && scoreSnapshot.noMissMultiplier <= 1) {
            adjustment += 8
        }

        if (scoreSnapshot.connectionMultiplier >= 1.32) {
            adjustment -= 6
        }

        return adjustment
    }

    private getOscillation(timeLeft: number): number {
        return ((GameConfig.SESSION_SECONDS - timeLeft) * 11) % 8
    }

    private getDefaultMessage(playerScore: number, timeLeft: number): string {
        const diff = playerScore - this.rivalScore

        if (timeLeft <= 12 && Math.abs(diff) <= 120) {
            return 'PHOTO FINISH'
        }

        if (diff >= 480) {
            return 'HOLD LEAD'
        }

        if (diff <= -480) {
            return 'CHASE'
        }

        return 'CLASH'
    }

    private getState(scoreDiff: number): BattleState {
        if (scoreDiff > 0) {
            return 'ahead'
        }

        if (scoreDiff < 0) {
            return 'behind'
        }

        return 'tied'
    }
}
